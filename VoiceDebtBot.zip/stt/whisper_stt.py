# STT logic using OpenAI Whisper or Google STT
