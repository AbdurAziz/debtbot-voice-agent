# Call GPT-3.5 or GPT-4 to generate response
